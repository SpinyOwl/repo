package org.liquidengine.legui.component;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.joml.Vector2f;

/**
 * Layer one of base structures. Holds layer containers which are used to hold all of other components. <p> Layer can be eventPassable - that's mean that
 * current layer allow to pass events to bottom layer if event wasn't handled by components of this layer. <p> Also layer can be eventReceivable - that's mean
 * that current layer and all of it components can receive events. For example {@link TooltipLayer} is eventPassable and isn't eventReceivable.
 *
 * @param <T> type of components for {@link LayerContainer}
 */
public class Layer<T extends Component> {

    /**
     * Used to hold all components of layer.
     */
    protected LayerContainer<T> container = new LayerContainer<>();
    /**
     * Parent frame.
     */
    private Frame frame;
    /**
     * Determines if  current layer allow to pass events to bottom layer if event wasn't handled by components of this layer.
     */
    private boolean eventPassable = true;
    /**
     * Determines if current layer and all of it components can receive events.
     */
    private boolean eventReceivable = true;

    /**
     * Returns frame to which attached this layer.
     *
     * @return frame to which attached this layer.
     */
    public Frame getFrame() {
        return frame;
    }

    /**
     * Used to attach layer to frame.
     *
     * @param frame frame to attach.
     */
    protected void setFrame(Frame frame) {
        if (!frame.containsLayer(this)) {
            frame.addLayer(this);
        }
        this.frame = frame;
    }

    /**
     * Returns component container.
     *
     * @return component container.
     */
    public LayerContainer<T> getContainer() {
        return container;
    }

    /**
     * Used to set custom layer container.
     *
     * @param container new layer container to set.
     */
    public void setContainer(LayerContainer<T> container) {
        container.setSize(new Vector2f(this.container.getSize()));
        this.container = container;
    }

    /**
     * Returns true if layer is event passable.
     *
     * @return true if layer is event passable.
     */
    public boolean isEventPassable() {
        return eventPassable;
    }

    /**
     * Used to enable or disable passing events to bottom layer.
     *
     * @param eventPassable true/false to enable/disable passing events to bottom layer.
     */
    public void setEventPassable(boolean eventPassable) {
        this.eventPassable = eventPassable;
    }

    /**
     * Returns true if layer is event receivable.
     *
     * @return true if layer is event receivable.
     */
    public boolean isEventReceivable() {
        return eventReceivable;
    }

    /**
     * Used to enable or disable receiving events by layer.
     *
     * @param eventReceivable true/false to enable/disable receiving events by layer.
     */
    public void setEventReceivable(boolean eventReceivable) {
        this.eventReceivable = eventReceivable;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
            .append(getContainer())
            .append(isEventPassable())
            .append(isEventReceivable())
            .toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Layer<?> layer = (Layer<?>) obj;

        return new EqualsBuilder()
            .append(isEventPassable(), layer.isEventPassable())
            .append(isEventReceivable(), layer.isEventReceivable())
            .append(getContainer(), layer.getContainer())
            .isEquals();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
            .append("container", getContainer())
            .append("eventPassable", isEventPassable())
            .append("eventReceivable", isEventReceivable())
            .toString();
    }
}
