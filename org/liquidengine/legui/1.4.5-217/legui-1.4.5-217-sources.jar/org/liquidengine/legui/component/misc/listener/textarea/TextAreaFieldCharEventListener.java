package org.liquidengine.legui.component.misc.listener.textarea;

import static org.liquidengine.legui.input.Mouse.MouseButton.MOUSE_BUTTON_LEFT;
import static org.liquidengine.legui.util.TextUtil.cpToStr;

import org.liquidengine.legui.component.TextAreaField;
import org.liquidengine.legui.component.event.textarea.TextAreaFieldUpdateEvent;
import org.liquidengine.legui.component.optional.TextState;
import org.liquidengine.legui.event.CharEvent;
import org.liquidengine.legui.listener.CharEventListener;
import org.liquidengine.legui.listener.processor.EventProcessor;

/**
 * Char event listener for text area. Used to fill text area with symbols entered via keyboard.
 */
public class TextAreaFieldCharEventListener implements CharEventListener {

    /**
     * Used to handle {@link CharEvent}.
     *
     * @param event event to handle.
     */
    @Override
    public void process(CharEvent event) {
        TextAreaField textAreaField = (TextAreaField) event.getTargetComponent();
        if (textAreaField.isFocused() && textAreaField.isEditable() && !MOUSE_BUTTON_LEFT.isPressed()) {
            String str = cpToStr(event.getCodepoint());
            TextState textState = textAreaField.getTextState();
            int start = textAreaField.getStartSelectionIndex();
            int end = textAreaField.getEndSelectionIndex();
            if (start > end) {
                start = textAreaField.getEndSelectionIndex();
                end = textAreaField.getStartSelectionIndex();
            }
            if (start != end) {
                textState.delete(start, end);
                textAreaField.setCaretPosition(start);
                textAreaField.setStartSelectionIndex(start);
                textAreaField.setEndSelectionIndex(start);
            }
            int caretPosition = textAreaField.getCaretPosition();
            textState.insert(caretPosition, str);
            int newCaretPosition = caretPosition + str.length();
            textAreaField.setCaretPosition(newCaretPosition);
            textAreaField.setEndSelectionIndex(newCaretPosition);
            textAreaField.setStartSelectionIndex(newCaretPosition);

            EventProcessor.getInstance().pushEvent(new TextAreaFieldUpdateEvent(textAreaField, event.getContext(), event.getFrame()));
        }
    }

    @Override
    public boolean equals(Object obj) {
        return (obj != null) && ((obj == this) || ((obj != this) && (obj.getClass() == this.getClass())));
    }
}
