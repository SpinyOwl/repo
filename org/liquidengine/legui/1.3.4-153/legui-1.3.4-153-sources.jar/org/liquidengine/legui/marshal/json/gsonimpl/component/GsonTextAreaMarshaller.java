package org.liquidengine.legui.marshal.json.gsonimpl.component;

import static org.liquidengine.legui.marshal.JsonConstants.CARET_POSITION;
import static org.liquidengine.legui.marshal.JsonConstants.EDITABLE;
import static org.liquidengine.legui.marshal.JsonConstants.TAB_SIZE;
import static org.liquidengine.legui.marshal.JsonConstants.TEXT_STATE;
import static org.liquidengine.legui.marshal.json.gsonimpl.GsonUtil.isNotNull;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.liquidengine.legui.component.TextArea;
import org.liquidengine.legui.component.optional.TextState;
import org.liquidengine.legui.marshal.json.gsonimpl.GsonMarshalContext;
import org.liquidengine.legui.marshal.json.gsonimpl.GsonMarshalUtil;
import org.liquidengine.legui.marshal.json.gsonimpl.GsonUtil;

/**
 * Marshaller for {@link TextArea}.
 */
public class GsonTextAreaMarshaller<T extends TextArea> extends GsonComponentMarshaller<T> {

    /**
     * Reads data from object and puts it to json object.
     *
     * @param object object to read.
     * @param json json object to fill.
     * @param context marshal context.
     */
    @Override
    protected void marshal(T object, JsonObject json, GsonMarshalContext context) {
        super.marshal(object, json, context);

        JsonObject textState = GsonMarshalUtil.marshalToJson(object.getTextState(), context);
        GsonUtil.fill(json)
            .add(EDITABLE, object.isEditable())
            .add(TEXT_STATE, textState)
            .add(CARET_POSITION, object.getCaretPosition())
            .add(TAB_SIZE, object.getTabSize())
        ;
    }

    /**
     * Reads data from json object and puts it to object.
     *
     * @param json json object to read.
     * @param object object to fill.
     * @param context marshal context.
     */
    @Override
    protected void unmarshal(JsonObject json, T object, GsonMarshalContext context) {
        super.unmarshal(json, object, context);

        JsonElement editable = json.get(EDITABLE);
        JsonElement textState = json.get(TEXT_STATE);
        JsonElement caretPosition = json.get(CARET_POSITION);
        JsonElement tabSize = json.get(TAB_SIZE);

        if (isNotNull(textState)) {
            JsonObject asJsonObject = textState.getAsJsonObject();
            TextState state = GsonMarshalUtil.unmarshal(asJsonObject, context);
            object.getTextState().copy(state);
        }
        if (isNotNull(editable)) {
            object.setEditable(editable.getAsBoolean());
        }
        if (isNotNull(caretPosition)) {
            object.setCaretPosition(caretPosition.getAsInt());
        }
        if (isNotNull(tabSize)) {
            object.setTabSize(tabSize.getAsInt());
        }
    }
}
